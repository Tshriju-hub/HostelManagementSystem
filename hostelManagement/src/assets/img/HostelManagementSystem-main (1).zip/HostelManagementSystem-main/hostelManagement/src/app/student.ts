export interface Student {
    roomCategory : string;
    roomNo: number;
    personNo: number;
    firstName: string;
    lastName: string;
    fatherName: string;
    gender: string;
    mobileNo: number;
    fatherMobileNo: number;
    email: string;
    currentAdress: string;
    collegeName: string;
    isStatus: boolean;
}
